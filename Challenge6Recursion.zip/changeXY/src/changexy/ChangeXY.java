/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package changexy;

/**
 *
 * @author Khalil Tobias
 * Date: 3/27/2023 
 * Instructor: Professor Cristy Charters
 * Class: Intermediate Java COP 3804
 */
public class ChangeXY 
{
    public static String changeXY(String str)
    {
        // base case: if the string is empty. return an empty string
        
        if(str.length() == 1)
        {
            if(str.charAt(0) == 'x')
            {
                return "c";
            }
            else
            {
                return str;
            }
        }
        
        // Recursive case: replace 'x' with 'y' and call the function recursively on the rest of the string 
        char firstChar = str.charAt(0);
        if(firstChar == 'x')
        {
            return 'y' + changeXY(str.substring(1));
        }
        else
        {
            return firstChar + changeXY(str.substring(1));
        }
    }
    
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        String input = "codex";
        String output = changeXY(input);
       // prints "yyhiyy"
        System.out.println(output);
        
        String input1 = "xxhixx";
        String output1 = changeXY(input1);
        //prints "codey"
        System.out.println(output1);
        
        String input2 = "xhixhix";
        String output2 = changeXY(input2);
        // prints "yhiyhi"
        System.out.println(output2);
    }
    
    
}
